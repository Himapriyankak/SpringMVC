package com.techpalle.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.techpalle.model.Employee;


public class DataAcess {
	public void delete(int id) {
		Connection c = null;
		PreparedStatement ps =null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 c = DriverManager.getConnection("jdbc:mysql://localhost:3306/Spring", "root", "admin");
		 ps = c.prepareStatement("delete from student where sno=?");
		ps.setInt(1, id);
		ps.executeUpdate();
		} 
		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(ps!=null) {
				try {
					ps.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(c!=null) {
				try {
					c.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
public void update(Employee s) {
	Connection c = null;
	PreparedStatement ps =null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		 c = DriverManager.getConnection("jdbc:mysql://localhost:3306/Spring", "root", "admin");
	 ps = c.prepareStatement("update student set sname=?,email=?,pw=?,mobile=? where sno=?");
	ps.setString(1, s.getName());
	ps.setString(2,s.getEmail());
	ps.setString(3,s.getPassword());
	ps.setLong(4,s.getMobile());
	ps.setInt(5, s.getId());
	ps.executeUpdate();
	} 
	catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		if(ps!=null) {
			try {
				ps.close();
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
		}
		if(c!=null) {
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
public Employee getEmployeesById(int id) {
	Employee s = new Employee();
	Connection c = null;
	PreparedStatement ps =null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		c = DriverManager.getConnection("jdbc:mysql://localhost:3306/Spring", "root", "admin");
		ps =c.prepareStatement("select * from Student where sno = ?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			s.setId(id);
			s.setName(rs.getString("sname"));
			s.setEmail(rs.getString("email"));
			s.setPassword(rs.getString("pw"));
			s.setMobile(rs.getLong("mobile"));
			
		}
		}
	catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		if(ps!=null) {
			try {
				ps.close();
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
		}
		if(c!=null) {
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	return s;
}
	public void insert(Employee s) {
		Connection c = null;
		PreparedStatement ps =null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 c = DriverManager.getConnection("jdbc:mysql://localhost:3306/Spring", "root", "admin");
		 ps = c.prepareStatement("insert into Student(sname,email,pw,mobile) values(?,?,?,?)");
		ps.setString(1, s.getName());
		ps.setString(2,s.getEmail());
		ps.setString(3,s.getPassword());
		ps.setLong(4,s.getMobile());
		ps.executeUpdate();
		} 
		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(ps!=null) {
				try {
					ps.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(c!=null) {
				try {
					c.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public ArrayList<Employee>getAllEmployees(){
		ArrayList<Employee> a1 = new ArrayList<Employee>();
		
		Connection c = null;
		Statement s =null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 c = DriverManager.getConnection("jdbc:mysql://localhost:3306/Spring", "root", "admin");
		s =  c.createStatement();
		ResultSet rs = s.executeQuery("select * from Student");
		while(rs.next()) {
			int i = rs.getInt("sno");
			String n = rs.getString("sname");
			String e = rs.getString("email");
			String p = rs.getString("pw");
			long m = rs.getLong("mobile");
			Employee et = new Employee(i,n,e,p,m);
			a1.add(et);
				} }
		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(s!=null) {
				try {
					s.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(c!=null) {
				try {
					c.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return a1;
		
	}
}
