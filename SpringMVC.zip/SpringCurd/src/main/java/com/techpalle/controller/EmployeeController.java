package com.techpalle.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.techpalle.DAO.DataAcess;
import com.techpalle.model.Employee;



@Controller
public class EmployeeController {
	@RequestMapping("delete")
	public ModelAndView deleteEmployee(int id) {
		ModelAndView mv = new ModelAndView();
		DataAcess da = new DataAcess();
		da.delete(id);
		ArrayList<Employee> a1 = da.getAllEmployees();
		mv.addObject("1st",a1);
		mv.setViewName("display.jsp");
		return mv;
		}
	@RequestMapping("update")
	public ModelAndView updateEmployee(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
	//read the data from the register.jsp
		int i =	Integer.parseInt(request.getParameter("tbId"));
	String n = request.getParameter("tbName");
	String e = request.getParameter("tbEmail");
	String p = request.getParameter("tbPass");
 long m = Long.parseLong(request.getParameter("tbMobile"));
 Employee s = new Employee(i,n,e,p,m);
		// update the value in DB
		DataAcess da = new DataAcess();
		da.update(s);
		//


		return mv;

	}
	
	
	@RequestMapping("edit")
	public ModelAndView displayEditForm(int id) {
		ModelAndView mv = new ModelAndView();
		DataAcess da = new DataAcess();
		Employee e=da.getEmployeesById(id);
		mv.addObject("student",e);
		mv.setViewName("register.jsp");
		
		return mv;

	}
	@RequestMapping(value="CRUD", params ="Show")
	public ModelAndView showAllStudents() {
		ModelAndView mv = new ModelAndView();
		DataAcess da = new DataAcess();
		ArrayList<Employee> a1 = da.getAllEmployees();
		mv.addObject("1st",a1);
		mv.setViewName("display.jsp");
		return mv;
		
	}
	@RequestMapping(value="CRUD", params ="Register")
	public ModelAndView goToRegisterPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("register.jsp");
		return mv;
		
	}
	@RequestMapping("Register")
	public ModelAndView insertStudent(HttpServletRequest request) {
		String n =request.getParameter("tbName");
		String e =request.getParameter("tbEmail");
		String pw =request.getParameter("tbPass");
		long mb =Long.parseLong(request.getParameter("tbMobile"));
		Employee s = new Employee(n,e,pw,mb);
	DataAcess d = new DataAcess();
	d.insert(s);
	ModelAndView mv = new ModelAndView();
	mv.addObject("res","inserted");
	mv.setViewName("register.jsp");
	return mv;
	}	

}
